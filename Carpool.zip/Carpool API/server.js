var express = require('express'),
  app = express(),
  port = process.env.PORT || 3000;

//app.listen(port);

app.listen(3000, () => {
    console.log("Server running on port 3000");
   });

console.log('todo list RESTful API server started on: ' + port);