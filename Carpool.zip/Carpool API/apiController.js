

exports.login = function(req, res) {
    console.log("Server is ready");
    response.writeHead(200);
    response.write('Hello Noders');
    response.end();
  };

